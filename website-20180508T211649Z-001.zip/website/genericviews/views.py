from django.shortcuts import render
from django.views import generic

from .forms import RestaurantForm
from .models import Restaurant
# Create your views here.
# normal view to handle the entry of the product and store it on the database
def makeentry(request):
    if request.method == 'POST':
        form = RestaurantForm(request.POST)

        if form.is_valid():
            name = request.POST.get('name', '')
            area= request.POST.get('area', '')
            dishes=request.POST.get('dishes','')
            #rate=4

        restaurant = Restaurant(name=name, area=area,dishes=dishes,rate='4')
        restaurant.save()

        form = RestaurantForm()

        return render(request, 'genericviews/makeentry.html', {'form': form})
    else:
        form = RestaurantForm()
        return render(request, 'genericviews/makeentry.html', {'form': form})


# generic view to fetch the data then show in a list
class IndexView(generic.ListView):
    # a name to refer to the object_list(to be used in the index.html)
    context_object_name = 'restaurant_list'
    template_name = 'genericviews/index.html'

    def get_queryset(self):
        return Restaurant.objects.all()


# generic view to show the details of a particular object
class DetailsView(generic.DetailView):
    model = Restaurant
    template_name = 'genericviews/detail.html'
