from django import forms

class RestaurantForm(forms.Form):
    # variable for the title of the restaurant
    name = forms.CharField(label="name", max_length=100)
    # variable for the description of the restaurant
    area = forms.CharField(label="area", max_length=100)

    dishes = forms.CharField(label="dishes", max_length=300, help_text="Write down the dishes.",
                           widget=forms.Textarea)
