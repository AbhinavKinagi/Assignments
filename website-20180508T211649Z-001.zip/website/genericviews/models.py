from django.db import models

# Create your models here.

class Restaurant(models.Model):
    # title of the watch
    name = models.CharField(max_length=100)
    # description of the watch
    area=models.CharField(max_length=100)
    dishes= models.CharField(max_length=300)
    rate=models.CharField(max_length=100)

    def __str__(self):
       return self.name

    #def __str__(self):
        #return self.area

    #def __str__(self):
        #return self.dishes
