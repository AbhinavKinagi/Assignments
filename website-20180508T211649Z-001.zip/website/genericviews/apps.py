from django.apps import AppConfig


class GenericviewsConfig(AppConfig):
    name = 'genericviews'
